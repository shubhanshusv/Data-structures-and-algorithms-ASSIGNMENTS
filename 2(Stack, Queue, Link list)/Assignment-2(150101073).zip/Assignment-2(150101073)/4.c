#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

/*
        MADE BY:

        SHUBHANSHU VERMA
        150101073


*/


struct node{

        int data;
        struct node *next;



};

struct node *top;                      // topmost element of stack
void createnode();                     // function to create a node
void push(struct node *p,int a);       // function to enter an element in stack (p is previous first element of stack)(a is data)
void pop();                            // function to remove an element in a stack
int stack_elements();                  // function to count no. of elements in stack

                    /*

                        Stack is implemented using link list.
                        topmost element of stack is first element of link list
                        in stack topmost element is popped out,so first element of link list is popped out.
                        element in stack is also inserted at top, so element is inserted in beginning of link list.


                    */







int main()
{



    /* First we generate a random array of numbers ranging from 0 to 10000. */
    /* functions srand() and rand() are used for this purpose.*/

     srand(time(NULL));

     int i,j,n,x;   /* i,j are index integers. n is no. of elements in array.x for user input */

     printf("Enter the size of array u wanna create.\n");
     scanf("%d",&n);   /* take input from user the length of the random array.*/

     int a[n];  /* a is the array of random integers */
     int s[n];  // array of span of elements of a.


     printf("Press 1 for user input or 0 for randum input.\n");
     scanf("%d",&x);



    if(x==1){

        printf("Enter %d elements.\n",n);

            for(i=0;i<n;i++){

                scanf("%d",&a[i]);
                s[i] = 0;

            }



    }else{


        for(i=0;i< n;i++){

        a[i] = rand() % 10001;  // A random value ranging from 0 to 10000 is assigned to ith element of a.
        s[i] = 0;


        }


        printf("Generated array\n");

        for(i = 0; i < n; i++){

            printf("%d ", a[i]);      // The random array generated is first printed.

        }





    }


    printf("\n\nSpan array is\n");






    // algorithm of order n^2 for finding span array
    // EVERY ELEMENT IS COMPARED TO ITS PREVIOUS ELEMENTS TILL AN ELEMENT GREATER
    // THAN THE PRESENT ELEMENT IS NOT FOUND


    for(i=0;i<n;i++){

        j = i;

        // EVERY ELEMENT IS COMPARED TO ITS PREVIOUS ELEMENTS TILL AN ELEMENT GREATER
        // THAN THE PRESENT ELEMENT IS NOT FOUND

            while(a[j] <= a[i] && j >= 0){

                s[i] ++;        // span value is incremented
                j--;
            }

    }

    for(i=0;i<n;i++)
        printf("%d ",s[i]);




     // O(n) algorithm for the same using stack on same array.

     struct node *p;
     top = NULL;

     createnode();
     top->data = 0;

     // Create a stack and push index of first element to it



        // Span value of first element is always 1
        s[0] = 1;


        // Calculate span values for rest of the elements

   for (i = 1; i < n; i++)
   {


      // Pop elements from stack while stack is not empty and top of stack is smaller than a[i]


     while (stack_elements()!= 0 && a[top->data] <= a[i]){

            pop();

      }


      /* If stack becomes empty, then a[i] is greater than all elements
         on left of it, i.e., a[0], a[1],..a[i-1].  Else a[i]
         is greater than elements after top of stack */

        if(stack_elements() == 0){

                s[i] = i+1;

        }else{

                s[i] = i - top->data;

        }

      // Push this element to stack

      p = top;
      push(p,i);


   }


        // generated span array is printed
        printf("\n\nSpan array using stack is\n");

         for(i=0;i<n;i++)
        printf("%d ",s[i]);








     return 0;
}

// Function to create a node

void createnode(){

        struct node *newnode,*currentnode;

        newnode = (struct node*)malloc(sizeof(struct node));

        newnode->data = rand() % 10 + 0;

        newnode->next = NULL;

        // if top is null, then new element is made top element
        if(top == NULL){

                top = newnode;
                currentnode = newnode;


        }else{

                currentnode->next = newnode;
                currentnode = newnode;

        }

}



// Function to push an element in a stack

void push(struct node *p, int a){

        struct node *newnode;

        newnode = (struct node*)malloc(sizeof(struct node));

        // New element inserted is topmost element of stack
        // So new element is inserted at beginning of link list

        newnode->data = a;

        newnode->next = p;
        top = newnode;

}




// Function to pop out an element of a stack

void pop(){

                struct node *q;

                // top most element of stack is first element of link list
                // so first element of link list is freed

                q = top->next;
                free(top);
                top = q;

}




// Function to calculate no. of elements in a stack

int stack_elements(){

        struct node *p;
        p = top;            // p is assigned topmost element of stack;
        int x=0;            // to count no. of elements

                            // topmost element f stack is first element of link list

        while(p != NULL){


            x++;            // counter increases counting no. of elements
            p = p->next;    // p is assigned next element till it becomes null


        }


    return x;               // no. of elements is returned
}
