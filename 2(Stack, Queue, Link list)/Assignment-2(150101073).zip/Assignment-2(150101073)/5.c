#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>

/*
            MADE BY:

            SHUBHANSHU VERMA
            150101073


*/

int q_time;                         // Quantum time

struct node{

        int index1;                 // the process no.
        int index2;                 // stores how many time a process is executed
        int arrival_time;           //  arrival time of process
        int execution_time;         //  execution time of process
        struct node *next;          //  pointer pointing to next process


};

struct node *top;

void createnode(int a, int b, int c);     // function to create a node
void shift_top_to_last();                 // function that shifts starting node to last node
void kill_process();                      // function for deleting a node
void new_process(int a,int b,int c);      // function for creating a new node


int main(){

        int n,x;                           // n = no. of processes
        top = NULL;
        struct node *p;



        printf("Enter the no. of processes.\n");
        scanf("%d",&n);

        srand(time(NULL));




        int i,j;
        int a[n];               // array storing arrival time of processes
        int b[n];               // array storing execution time of processes
        int c[n];               // array storing process number (index of process)
        int d[n];               // array stores the times i th process is executed
        int time,gap;           // time counts increases till all the processes are executed
        int flag,temp;          // variables for sorting according to arrival time
        int max;                // max. execution time
        int m;

        max = 0;


        printf("\nPress 1 for user input or 0 for random input\n");
        scanf("%d",&x);


        if(x==0){

                // Random input generation

                for(i=0;i<n;i++){

                    a[i] = rand() % 1000 + 0;
                    b[i] = rand() % 1000 + 1;
                    c[i] = i;

                    if(max < b[i]){

                    max = b[i];

                    }

                }

                q_time = rand() % 200 + 10;

                printf("\nProcess        Arrival time      Execution time\n");

                for(i=0;i<n;i++){

                printf("%d                    %d                 %d\n",c[i],a[i],b[i]);



                }

                printf("quantum time = %d\n",q_time);


        }else{

                // Information about processes is taken



                printf("Enter the entry time and execution time of each process one by one.\n");
                printf("Arrival time   Execution time\n");

                for(i=0;i<n;i++){

                    scanf("%d",&a[i]);
                    scanf("%d",&b[i]);
                    c[i] = i;

                    if(max < b[i]){

                    max = b[i];

                    }

                }


                printf("Enter quantum time.\n");
                scanf("%d",&q_time);                          // quantum time entered by user





        }





        int pt[n][max];                                        // i th row of this 2d array stores the times when a process start executing.













        // Bubble sorting processes according to arrival time;


        while(1){

            flag = 0;

                for(i=0;i<n-1;i++){


                    if(a[i] > a[i+1]){

                        temp = a[i];
                        a[i] = a[i+1];
                        a[i+1] = temp;

                        temp = b[i];
                        b[i] = b[i+1];
                        b[i+1] = temp;

                        temp = c[i];
                        c[i] = c[i+1];
                        c[i+1] = temp;

                        flag = 1;

                    }

                }

            if(flag == 0){

                break;

            }

        }









        createnode(a[0],b[0],c[0]);                          // 1st process is created
        time = a[0];                                         // time counter starts from least arrival time
        i = 1;







        while(top != NULL){

            pt[top->index1][top->index2] = time;                // storing the time at which a process starts executing
            top->index2 ++;                                      // stores the time a process is executed



                if(top->execution_time  > q_time){              // if execution time > quantum time, then that process is executed for quantum time
                                                                // and then pushed at the end of the process queue

                    top->execution_time -= q_time;              // now for completion of that process , execution time -  q_time amount of time is required

                    re:
                    if(a[i] <= time + q_time && i<n){           // while execution of a process ,if any other process arrives, then it is added to queue

                            new_process(a[i],b[i],c[i]);        // node for new process is made
                            i++;
                            goto re;                             // this is recursively checked till all the processes whose arrival time is during the current process's
                                                                 // execution time arrives

                    }

                    shift_top_to_last();                         // once quantum time is over , process is added at last position in queue
                        time += q_time;                          // time counter is incremented by quantum time.


                }else{                                           // if execution time <= quantum time , the current process which is being executed will get completed

                        gap = top->execution_time;               // time required to complete

                        ree:
                        if(a[i] <= time + gap && i<n){          // while execution of a process ,if any other process arrives, then it is added to queue

                            new_process(a[i],b[i],c[i]);
                            i++;
                            goto ree;

                        }




                         if(top->next != NULL){                 // if queue is not empty

                            d[top->index1] = top->index2;       // no. of time process is executed is incremented by 1
                            kill_process();                     // process is completed , therefore , killed
                            time += gap;                        // time counter is incremented



                         }else if(top->next == NULL && i==n){   // if queue is empty but all processes are finished

                            d[top->index1] = top->index2;
                            kill_process();
                            time += gap;



                         }else if(top->next == NULL && i<n){       // if queue is empty but all processes are not finished
                                                                    // and arrival time of next process is > execution time (gap) of process

                                d[top->index1] = top->index2;       // current process is terminated and
                                                                    // time is incremented to arrival time of next closest process

                                top->index1 = c[i];                 // corresponding process node is made
                                top->index2 = 0;
                                top->arrival_time = a[i];
                                top->execution_time = b[i];
                                top->next = NULL;

                                time = a[i];
                                i++;


                         }



                }


        }

        printf("\n\n");





        // Now the duration in which each process is executed is printed


        for(i=0;i<n;i++){

            printf("Process %d : ",i);

            for(j=0;j<d[i];j++){

                if(b[i] >= q_time){             // m denotes execution time

                    m = q_time;
                    b[i] = b[i] - m;

                }else{

                    m = b[i];

                }

                if(m!= 0)
                printf("<%d-%d> ",pt[i][j],pt[i][j] + m);


            }


            printf("\n");

        }



    return 0;

}



// a: arrival time
// b : execution time
// c: index of process


// Function for creating a node

void createnode(int a,int b,int c){

        struct node *newnode,*currentnode;

        newnode = (struct node*)malloc(sizeof(struct node));

        newnode->index1 = c;
        newnode->index2 = 0;
        newnode->arrival_time = a;
        newnode->execution_time = b;
        newnode->next = NULL;

        if(top == NULL){

                top = newnode;
                currentnode = newnode;


        }else{

                currentnode->next = newnode;
                currentnode = newnode;

        }

}


// to delete a process

void kill_process(){

             struct node *p;

             p = top->next;

             free(top);
             top = p;
}


// shifting a process to end of queue

void shift_top_to_last(){

        struct node *newnode;

        newnode = (struct node*)malloc(sizeof(struct node));

        struct node *p;
        p = top;

        while(p->next != NULL){

            p = p->next;

        }



        newnode->index1 =  top->index1;
        newnode->index2 =  top->index2;
        newnode->arrival_time=  top->arrival_time;
        newnode->execution_time=  top->execution_time;
        p->next = newnode;
        newnode->next = NULL;

        kill_process();

}

// making a new process

void new_process(int a,int b,int c){

        struct node *newnode;

        newnode = (struct node*)malloc(sizeof(struct node));

        struct node *p;
        p = top;


            while(p->next != NULL){

            p = p->next;

            }



        newnode->index1 =  c;
        newnode->index2 =  0;
        newnode->arrival_time=  a;
        newnode->execution_time=  b;
        p->next = newnode;
        newnode->next = NULL;




}


