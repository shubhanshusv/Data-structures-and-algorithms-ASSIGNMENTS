#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>

/*


            MADE BY:

            SHUBHANSHU VERMA
            150101073




*/


struct node{

	int data;
	struct node *next;



};

struct node *start;

void createnode();
void insertnode(struct node *p);                // Function to insert node after element p
void insertstart(struct node *p);               // Function to insert node at start
void insertend(struct node *p);                 // Function to insert node at end
void deletenode(struct node*p);                 // Function to delete node after element p
void deletenodestart();                         // Function to delete node at start
void deletenodeend(struct node*p);              // Function to delete node at end
int cycle_detector(struct node *first);         // Function to check cycle in link list  returns 1 if cycle is present otherwise 0

int main(){

	int n,x,y,test;                                     // n = no. of elements , X IS FOR TAking user input, y for generating random no.
	start = NULL;
	struct node *p;
	struct node *q;
	srand(time(NULL));
	printf("Enter how many nodes u wanna create.\n");   // asking user no. of elements
	scanf("%d",&n);
	int b;

	int i;




    // creating random link list of n elements

	for(i=0;i<n;i++){

		createnode();

	}

	p = start;






    // printing generated link list

    printf("Generated link list:\n");

	for(i=0;i<n;i++){

		printf("%d ",p->data);

		p = p->next;

	}
	p = start;

	for(i=0;i<n-1;i++){

		p = p->next;

	}



    // asking user mode of input

    printf("\nPress 1 for user input\nPress 0 for random.\n");
    scanf("%d",&x);

    if(x==1){

        // asking user if he/she wants a cycle in link list

        printf("\nIf you want to create a cycle in link list ,press 1.\nIf no, press 0.\n ");
        scanf("%d",&x);

        if(x == 1){

        // if yes, then last element of link list is randomly linked to any other element of link list

            y = rand() %n;      // position to which last element is back linked


            q = start;

            for(i=0;i<y;i++){

                q = q->next;

            }

            p->next = q;

        }
	}else{


            x = rand() % 2 + 0;  // generating x randomly

            if(x == 1){

        // if x == 1, then last element of link list is randomly linked to any other element of link list

            y = rand() %n;      // position to which last element is back linked


            q = start;

            for(i=0;i<y;i++){

                q = q->next;

            }

            p->next = q;

        }


	}


    printf("Is there any cycle present??\n");
    test = cycle_detector(start);         // if cycle is present function returns 1, else 0.

    if(test == 0){

            printf("NO\n");

    }else if(test == 1){

            printf("yes\n");
            printf("element %d is back linked to element %d.\n",n,y+1);

    }

	return 0;






}

void createnode(){

	struct node *newnode,*currentnode;

	newnode = (struct node*)malloc(sizeof(struct node));

	newnode->data = rand() % 10000 + 0;

	newnode->next = NULL;


	if(start == NULL){

		start = newnode;
		currentnode = newnode;


	}else{

		currentnode->next = newnode;
		currentnode = newnode;

	}

}

// Function to check presence of cycle in a link list

int cycle_detector(struct node *first){

    // two nodes are created

    struct node *one;
    struct node *two;

    int flag=0;

    // both nodes are assigned first element of list

    one = first;
    two = first;

    // if anyone of nodes one , two , two->next becomes zero
    // we will infer that last element is not back linked to any element
    // so no cycle is present

    while(one && two && two->next){

        one = one->next;            // this node is incremented by 1 only
        two = two->next->next;      // this node is incremented by 2

        // if cycle is present both nodes will become same at a point

        if(one == two){

            flag++;
            break;

        }






    }

        return flag;

}



















// below functions are not needed in this program







// Function to insert node after element p

void insertnode(struct node *p){

	struct node *new;

	new = (struct node*)malloc(sizeof(struct node));

	printf("Enter the value of the node u wanna insert.\n");
	scanf("%d",&new->data);
	new->next = p->next;
	p->next = new;


}


// Function to insert node at start

void insertstart(struct node *p){

	struct node *new;

	new = (struct node*)malloc(sizeof(struct node));

	printf("Enter the value of the node u wanna insert.\n");
	scanf("%d",&new->data);

	new->next = p;
	start = new;

}

// Function to insert node at end

void insertend(struct node *p){

	struct node *new;

	new = (struct node*)malloc(sizeof(struct node));

	printf("Enter the value of the node u wanna insert.\n");
	scanf("%d",&new->data);

	p->next = new;
	new->next = NULL;



}

// Function to delete node after element p

void deletenode(struct node*p){

		struct node *q;

		q = p->next;
		p->next = q->next;
		free(q);

}

// Function to delete node at start

void deletenodestart(){

		struct node *q;

		q = start->next;
		free(start);
		start = q;

}

// Function to delete node at end

void deletenodeend(struct node*p){

		struct node *q;

		q = p->next;
		p->next = NULL;
		free(q);

}


