#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

/*
		Made by:
		SHUBHANSHU VERMA
		150101073

*/

int merge(int low, int mid, int high, int a[high+1]); // Function for merging two sorted arrays of length mid + 1 and high - mid.

int sort(int low, int high, int a[high+1]);  // Function for splitting an array int two arrays of length 1 + (low + high )/2 and (high - low)/2.


        /*Let A be an array of n elements.

          An inversion in A is a pair of elements x and y such that
          x appears before y in S but x > y.

          We can calculate no. of inversions in an array just by modifying
          merge sort algorithm a little bit.

          This is done by counting no. of inversions every time arrays are merged.

        */

int main() {


    /* First we generate a random array of numbers ranging from 0 to 10000. */
    /* functions srand() and rand() are used for this purpose.*/

     srand(time(NULL));

     int max,i,j,inversions;   /*n is the no. of integers in the array and i,j are index integers. */
     int a[500];  /* a is the array of random integers */

     printf("Enter the length of the array.\n");
     scanf("%d",&max);   /* take input from user the length of the random array.*/






    // RANDOM ARRAY A

     for(i=0;i< max;i++){

        a[i] = rand() % 10000;  // A random value ranging from 0 to 10000 is assigned to ith element of a.

     }

     printf("ARRAY A\n");

     for(i = 0; i < max; i++){

         printf("%d ", a[i]);      // The random array generated is first printed.

     }

     max--;  // since the max. index is 1 less than the no. of elements in an array, 1 is subtracted from max

    inversions = sort(0, max,a);        // array is given to the merge sort function.

     max++;

   printf("\nNo. of inversions are %d.\n",inversions);

   return 0;
}








/* Function for merging two sorted arrays of length mid + 1 and high - mid, and
    also counting no. of inversions side by side.

    low is the lowest index that the array has. for example a[2] to a[7] , this array has low = 2.
    high is the highest index that the array has. for example a[2] to a[7] , this array has high = 7.
    mid = (low + high)/2 rounded down, for example mid = (2+7)/2 = 4.
    and the array to be sorted is also provided.

*/



int merge(int low, int mid, int high, int a[high+1]) {

    int i = low;
    int j = mid + 1;
    int count=0;    //This will keep count of the no. of inversions.
    int k = 0;
    int b[high];    // A separate array of the same size as a is made.

    // The array between (low and mid) and the array between (mid + 1 and high) are sorted and now are being merged.

    while (i <= mid && j <= high) {

        // An inversion will occur if an element in array1(<= mid) is greater than a member in array2(>mid).

        if (a[i] > a[j]){

            b[k++] = a[j++];
            count = count + (1 + mid - i);     /* here since both arrays to be merged are sorted
                                                so if an element in array1 ,let x,is greater than an element in array 2,
                                                all elements in array1 ahead of x will also be greater than that element in array2.
                                                so inversion will occur in all cases.
                                                */

        }else{

            b[k++] = a[i++];

        }
    }

    // the while loop may be terminated by exhaustion of any one condition
    // so some entries might still be remaining
    // Remaining entries are filled using the code below.

    while (i <= mid)
        b[k++] = a[i++];

    while (j <= high)
        b[k++] = a[j++];

    // Now the original array is updated by transferring sorted array from duplicate array b.

    k--;
    while (k >= 0) {
        a[low + k] = b[k];
        k--;
    }

    return count;   // no. of inversions is returned.

}












/*  Function for splitting an array int two arrays of length 1 + (low + high )/2 and (high - low)/2.

    low is the lowest index that the array has. for example a[2] to a[7] , this array has low = 2.
    high is the highest index that the array has. for example a[2] to a[7] , this array has high = 7.

       and the array to be sorted is also provided.


*/

int sort(int low, int high , int a[high+1]) {

   int mid;     // mid is basically (low + high)/2 rounded down.
   int x,y,z;
   // the provided array is continuously splitted till low = high. ,i.e, only single element remains

   if(low < high) {

      mid = (low + high) / 2;
      x = sort(low, mid,a);
      y = sort(mid+1, high,a);
      z = merge(low, mid, high ,a);     // and the splitted arrays are merged together.

   }else{

        return 0;   // an array of only 1 element will have 0 inversions.

   }

   return x+y+z;    // total inversions will be sum of inversions of array1 and array2 ,
                    // combined with the inversions that occur between array1 and array2.

}
