#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>


/*

        Made by:
        SHUBHANSHU VERMA
        150101073




*/


        // MERGE SORT

void merge(int low, int mid, int high, int a[high+1]); // Function for merging two sorted arrays of length mid + 1 and high - mid.

void sort(int low, int high, int a[high+1]);  // Function for splitting an array int two arrays of length 1 + (low + high )/2 and (high - low)/2.

int main() {


    /* First we generate a random array of numbers ranging from 0 to 10000. */
    /* functions srand() and rand() are used for this purpose.*/

     srand(time(NULL));

     int a[500];  /* a is the array of random integers */

     int max,i,j;   /*n is the no. of integers in the array and i,j are index integers. */

     printf("Enter the size of array u wanna create.\n");
     scanf("%d",&max);   /* take input from user the length of the random array.*/

     for(i=0;i< max;i++){

        a[i] = rand() % 10001;  // A random value ranging from 0 to 10000 is assigned to ith element of a.

     }


     printf("List before sorting\n");

     for(i = 0; i < max; i++){

         printf("%d ", a[i]);      // The random array generated is first printed.

     }

     max--;  // since the max. index is 1 less than the no. of elements in an array, 1 is subtracted from max

     sort(0, max,a);        // array is given to the merge sort function.

     printf("\nList after sorting\n");

     max++;

     for(i = 0; i < max; i++){

        printf("%d ",a[i]);         // The sorted array is printed.

     }
}

/* Function for merging two sorted arrays of length mid + 1 and high - mid.

    low is the lowest index that the array has. for example a[2] to a[7] , this array has low = 2.
    high is the highest index that the array has. for example a[2] to a[7] , this array has high = 7.
    mid = (low + high)/2 rounded down, for example mid = (2+7)/2 = 4.
    and the array to be sorted is also provided.

*/

void merge(int low, int mid, int high, int a[high+1]) {

    int i = low;
    int j = mid + 1;
    int k = 0;
    int b[high];  // A separate array of the same size as a is made.

    // The array between (low and mid) and the array between (mid + 1 and high) are sorted and now are being merged.

    while (i <= mid && j <= high) {
        if (a[i] <= a[j])               // the lower values of the two arrays are filled first
            b[k++] = a[i++];
        else
            b[k++] = a[j++];
    }

    // the while loop may be terminated by exhaustion of any one condition
    // so some entries might still be remaining
    // Remaining entries are filled using the code below.

    while (i <= mid)
        b[k++] = a[i++];

    while (j <= high)
        b[k++] = a[j++];

    // Now the original array is updated by transferring sorted array from duplicate array b.

    k--;
    while (k >= 0) {
        a[low + k] = b[k];
        k--;
    }

}

/*  Function for splitting an array int two arrays of length 1 + (low + high )/2 and (high - low)/2.

    low is the lowest index that the array has. for example a[2] to a[7] , this array has low = 2.
    high is the highest index that the array has. for example a[2] to a[7] , this array has high = 7.

       and the array to be sorted is also provided.


*/

void sort(int low, int high , int a[high+1]) {

   int mid; // mid is basically (low + high)/2 rounded down.

   // the provided array is continuously splitted till low = high. ,i.e, only single element remains

   if(low < high) {

      mid = (low + high) / 2;
      sort(low, mid,a);
      sort(mid+1, high,a);
      merge(low, mid, high ,a);     // and the splitted arrays are merged together.

   }

}

