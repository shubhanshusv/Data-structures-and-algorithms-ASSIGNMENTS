#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

/*
	Made by:
	SHUBHANSHU VERMA
	150101073

*/


void merge(int low, int mid, int high, int a[high+1]); // Function for merging two sorted arrays of length mid + 1 and high - mid.

void sort(int low, int high, int a[high+1]);  // Function for splitting an array int two arrays of length 1 + (low + high )/2 and (high - low)/2.


/*
        In this program we are given two random arrays and we have to tell whether the sum of any two integers,
        one from each array a and b, is equal to a given integer m.

        the time complexity of the program should be nlogn , so we apply binary searching.

        since binary search is effective only on a sorted array, therefore we first sort one array,b, and then
        check whether any integer in b is equal to m - a[i].
        we use merge sort as time complexity of merge sort is of the order nlogn.

        binary searching an element in an array of size n is of order log n as every time the element to be searched is
        compared to the middle element of the array and then accordingly half of the array is discarded depending
        on the middle value, thereby reducing the number of comparisons.

        binary searching n elements in an array of size n is therefore of the order of nlogn.

*/


int main()
{

    int n;                    // no. of elements in each array.
    printf("Enter how many elements you want in your array.\n");
    int i,j;                  // index integers
    int m;                    // the integer which is to be checked,i.e, a + b = m
    int low,high,mid;         // for binary searching
    int flag;                 // to check whether there is a combination  present such that a+b = m or not

    scanf("%d",&n);           // size of arrays inputted by user

    int a[n],b[n];            // arrays formed










    srand(time(NULL));

    // RANDOM ARRAY A IS GENERATED

    for(i=0;i< n;i++){

        a[i] = rand() % 10001;  //  random value ranging from 0 to 10000 is assigned to ith element of a.

     }


   printf("Array a\n");

   for(i = 0; i < n; i++){

         printf("%d ", a[i]);      // The random array generated is first printed.

   }

   // RANDOM ARRAY B IS GENERATED

    for(i=0;i< n;i++){

        b[i] = rand() % 10001;  // A random value ranging from 0 to 10000 is assigned to ith element of a.

     }


   printf("\nArray b\n");

   for(i = 0; i < n; i++){

         printf("%d ", b[i]);      // The random array generated is first printed.

   }

    printf("\n");







    sort(0, n-1,b);           // array b is merge sorted so that binary searching in it can be done
                              // and order remains nlogn.

    printf("Enter the value of m, for which u wanna check whether a + b = m .\n");
    scanf("%d",&m);           // int m taken from user

    flag = 0;                 // flag initialized to 0. if there is a pair (a,b) present then flag will become 1.

    printf("a + b = m\n");




    // BINARY SEARCHING FOR EVERY ELEMENT OF B such that b[i] = m - a[j]



    for(i=0;i<n;i++){

    low = 0;            // low and high are assigned highest and lowest indices
    high=n-1;

            while(low <= high){

                    mid = (low+high)/2;

                    // now it is checked that if m-a[i] occurs in b, then whether it is in first half of the array or  second half.

                    if(b[mid] == m - a[i]){


                    printf("%d + %d = %d \n",a[i] , b[mid],m);
                    flag = 1;
                    break;

                    }else if(b[mid] > m - a[i]){

                    high = mid-1;       // since m-a[i] < b[mid] , then binary searching will proceed in first half of array.

                    }else{

                    low = mid+1;        // since m-a[i] > b[mid] , then binary searching will proceed in second half of array.
                    }

                // if key is not found , at one point low and high will become equal and loop will be terminated.

            }

    }


    printf("Is there any pair of integer (a,b) such that a+b = m ?.\n");

    // now the answer is displayed whether there is a possible pair or not.

    if(flag==0){

        printf("NO\n");

    }else{

        printf("YES\n");

    }




    return 0;
}




/* Function for merging two sorted arrays of length mid + 1 and high - mid.

    low is the lowest index that the array has. for example a[2] to a[7] , this array has low = 2.
    high is the highest index that the array has. for example a[2] to a[7] , this array has high = 7.
    mid = (low + high)/2 rounded down, for example mid = (2+7)/2 = 4.
    and the array to be sorted is also provided.

*/

void merge(int low, int mid, int high, int a[high+1]) {

    int i = low;
    int j = mid + 1;
    int k = 0;
    int b[high];  // A separate array of the same size as a is made.

    // The array between (low and mid) and the array between (mid + 1 and high) are sorted and now are being merged.

    while (i <= mid && j <= high) {
        if (a[i] <= a[j])               // the lower values of the two arrays are filled first
            b[k++] = a[i++];
        else
            b[k++] = a[j++];
    }

    // the while loop may be terminated by exhaustion of any one condition
    // so some entries might still be remaining
    // Remaining entries are filled using the code below.

    while (i <= mid)
        b[k++] = a[i++];

    while (j <= high)
        b[k++] = a[j++];

    // Now the original array is updated by transferring sorted array from duplicate array b.

    k--;
    while (k >= 0) {
        a[low + k] = b[k];
        k--;
    }

}

/*  Function for splitting an array int two arrays of length 1 + (low + high )/2 and (high - low)/2.

    low is the lowest index that the array has. for example a[2] to a[7] , this array has low = 2.
    high is the highest index that the array has. for example a[2] to a[7] , this array has high = 7.

       and the array to be sorted is also provided.


*/

void sort(int low, int high , int a[high+1]) {

   int mid; // mid is basically (low + high)/2 rounded down.

   // the provided array is continuously splitted till low = high. ,i.e, only single element remains

   if(low < high) {

      mid = (low + high) / 2;
      sort(low, mid,a);
      sort(mid+1, high,a);
      merge(low, mid, high ,a);     // and the splitted arrays are merged together.

   }

}


